//AUTOCOMPLETAR
function autoCompleteRegimenFiscal(){
    $('#regimenFiscal').autocomplete({
        source: "../CATSTAT/com.sine.enlace/enlaceProdServ.php?transaccion=autocompleta",
        select: function (event, ui) {
            var c_regimen = ui.item.c_regimenfiscal;
            var desc_regimen = ui.item.descripcion_regimen;
            $('#c_regimenFiscal').val(c_regimen);
            $('#desc_regimenFiscal').val(desc_regimen);
        }
    });
}

//GET SELECT
function getOptions(){
    $.ajax({
        data : {transaccion: 'getOptions'},
        url  : 'com.sine.enlace/enlaceRegimenFiscal.php',
        type : 'POST',
        dataType : 'JSON',
        success  : function(res){
            if(res.status > 0){
                $('#contenedor_select_regimen').html(res.datos);
            }
        }
    });
}