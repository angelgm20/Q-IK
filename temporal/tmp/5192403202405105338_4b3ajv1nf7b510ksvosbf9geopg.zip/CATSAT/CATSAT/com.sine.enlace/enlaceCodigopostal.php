<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorCodigopostal.php';

if (isset($_REQUEST['transaccion'])) {

    $transaccion = $_REQUEST['transaccion'];
    $cC= new controladorCodigopostal();
    switch($transaccion){
        case 'buscarcp':
            $cp = $_POST['cp'];
            $datos = $cC->opcionesEstadoCP($cp);
            //$datosm = $cC->opcionesMunicipioCP($cp);
            echo json_encode($datos);
            //echo json_encode($datosm);
            break;
        case 'opcionesmunicipio':
            $id = $_POST['idestado'];
            $idmunicipio = $_POST['idmunicipio'];
            $datos = $cC->opcionesMunicipioByEstado($id, $idmunicipio);
            echo json_encode($datos);
            break;
        case 'opcionesestado':      
                $idestado = $_POST['idestado'];
                $datos = $cC->opcionesEstadoClv($idestado);
                echo json_encode($datos);
            break;
        case 'opcionesbanco':
                $idbanco = $_POST['idbanco'];
                $datos = $cC->opcionesBanco($idbanco);
               echo json_encode($datos);
                break;
        case 'addopcionesbanco':
                $a = $_POST['a'];
                $idbanco = $_POST['idbanco'];
                $datos = $cC->addopcionesBanco($a, $idbanco);
              echo json_encode($datos);
                break;
         
    }
}

