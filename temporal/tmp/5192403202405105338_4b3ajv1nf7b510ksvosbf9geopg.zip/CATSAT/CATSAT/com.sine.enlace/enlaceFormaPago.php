<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorFormaPago.php';

if (isset($_REQUEST['transaccion'])) {
    $transaccion = $_REQUEST['transaccion'];
    $cfp = new ControladorFormaPagos();

    switch($transaccion){
        case 'autocompleta':
            echo json_encode($cfp->getAutocomplete($_GET['term']));
            break;
        case 'getOptions':
            echo json_encode($cfp->getOptions());
            break;
    }
}