<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorEstado.php';

if (isset($_REQUEST['transaccion'])) {

    $transaccion = $_REQUEST['transaccion'];
    $cm= new ControladorEstado();

    switch($transaccion){
        case 'autocompleta':
            echo json_encode($cm->getAutocomplete($_GET['term']));
            break;
        case 'getOptions':
            echo json_encode($cm->getOptions());
            break;
    }
}