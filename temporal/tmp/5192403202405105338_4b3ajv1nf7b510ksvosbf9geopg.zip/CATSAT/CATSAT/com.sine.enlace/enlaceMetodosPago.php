<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorMetodosPago.php';

if (isset($_REQUEST['transaccion'])) {
    $transaccion = $_REQUEST['transaccion'];
    $cm = new controladorMetodoPago();

    switch($transaccion){
        case 'autocompleta':
            echo json_encode($cr->getAutocomplete($_GET['term']));
            break;
        case 'getOptions':
            echo json_encode($cr->getOptions());
            break;
    }
}