<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorRegimenFiscal.php';

if (isset($_REQUEST['transaccion'])) {

    $transaccion = $_REQUEST['transaccion'];
    $cm= new controladorRegimenFiscal();

    switch($transaccion){
        case 'autocompleta':
            echo json_encode($cm->getAutocomplete($_GET['term']));
            break;
        case 'getOptions':
            echo json_encode($cm->getOptions());
            break;
    }
}