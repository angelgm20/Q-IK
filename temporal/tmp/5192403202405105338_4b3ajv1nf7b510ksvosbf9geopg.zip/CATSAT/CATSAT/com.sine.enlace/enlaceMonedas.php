<?php
header('Content-type: application/json; charset=utf-8');
require_once '../com.sine.controlador/controladorMonedas.php';

if (isset($_REQUEST['transaccion'])) {
    $transaccion = $_REQUEST['transaccion'];
    $cm = new controladorMonedas();

    switch ($transaccion) {
        case 'autocompleta':
            echo json_encode($cm->getAutocomplete($_GET['term']));
            break;
        case 'getOptions':
            echo json_encode($cm->getOptions());
            break;
        case 'gettipocambio':
            $datos = $cm->getTipoCambio($_POST['idmoneda']);
            echo $datos != "" ? $datos : "0Error al obtener los datos.";
            break;
        case 'opcionesmoneda':
            $datos = $cm->opcionesMoneda($_POST['idmoneda']);
            echo $datos != "" ? $datos : "0Error al obtener los datos.";
            break;
    }
}
