<?php
require_once '../com.sine.dao/Consultas.php';


class ControladorEstado{
    
    private $consultas;

    function __construct(){  
        $this->consultas = new Consultas(); 
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_estados $condicion";
        $consultado = $this->consultas->getResults($query, null); 
        return $consultado;
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE c_estado LIKE '%$val%' OR nombre_estado LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_estado'].' - '.$rs['nombre_estado'];
            $json['c_estado'] = $rs['c_estado'];
            $json['nombre_estado'] = $rs['nombre_estado'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option value='".$rs['idestado']."'>".$rs['c_estado'].' - '.$rs['nombre_estado']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

    public function getEstadoAux($idestado) {
        $estado = "";
        $est = $this->getEstadoById($idestado);
        foreach ($est as $actual) {
            $estado = $actual['nombre_estado'];
        }
        return $estado;
    }
    
    private function getEstadoById($idestado) {
        $consultado = false;
        $consulta = "SELECT * FROM catalogos_sat.catalogo_estados WHERE idestado=:id;";
        $valores = array("id" => $idestado);
        $consultado = $this->consultas->getResults($consulta, $valores);
        return $consultado;
    }

}
?>