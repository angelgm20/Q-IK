<?php
require_once '../com.sine.dao/Consultas.php';

class ControladorFormaPagos
{

    private $consultas;

    function __construct()
    {
        $this->consultas = new Consultas();
    }

    public function getAutocomplete($val)
    {
        $contador = 0;
        $condicion = "WHERE c_formapagos LIKE '%$val%' OR descripcion LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach ($stmt as $rs) {
            $contador++;
            $json = array();
            $json['value'] = $rs['c_formapagos'] . ' - ' . $rs['descripcion'];
            $json['c_formapagos'] = $rs['c_formapagos'];
            $json['descripcion'] = $rs['descripcion'];
            $jsonArray[] = $json;
        }

        if ($contador == 0) {
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }
        return $jsonArray;
    }

    private function getDatosAux($condicion = "")
    {
        $query = "SELECT * FROM catalogos_sat.catalogo_forma_pagos $condicion";
        $consultado = $this->consultas->getResults($query, null);
        return $consultado;
    }

    public function getOptions()
    {
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach ($stmt as $rs) {
            $contador++;
            $datos .= "<option id='formapago" . $rs['idformapago'] . "' class='ps-5 text-start' value='" . $rs['idformapago'] . "'>" . $rs['c_formapago'] . ' - ' . $rs['descripcion'] . "</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

    public function getFormaById($idfp)
    {
        $consultado = false;
        $consulta = "SELECT * FROM catalogos_sat.catalogo_forma_pagos WHERE idformapago=:id;";
        $val = array("id" => $idfp);
        $consultado = $this->consultas->getResults($consulta, $val);
        return $consultado;
    }

    public function opcionesFormaPago($selected = "")
    {
        $pago = $this->getDatosAux("WHERE c_formapago !='99'");
        $r = "";
        foreach ($pago as $pagoactual) {
            $opt = "";
            if ($selected == $pagoactual['idformapago']) {
                $opt = "selected";
            }
            $r .= "<option $opt id='formapago" . $pagoactual['idformapago'] . "' value='" . $pagoactual['idformapago'] . "'>" . $pagoactual['c_formapago'] . ' ' . $pagoactual['descripcion'] . "</option>";
        }
        return $r;
    }

    public function getCFormaPago($idfp) {
        $cforma = "";
        $datos = $this->getFormaById($idfp);
        foreach ($datos as $actual) {
            $cforma = $actual['c_formapago'] . " " . $actual['descripcion'];
        }
        return $cforma;
    }

    public function getCMetodo($mid) {
        $c_moneda = "";
        $moneda = $this->getFormaById($mid);
        foreach ($moneda as $actual) {
            $c_moneda = $actual['c_formapago'];
        }
        return $c_moneda;
    }
}
