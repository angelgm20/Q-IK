<?php
require_once '../com.sine.dao/Consultas.php';
class controladorCodigopostal{
    
    private $con;

    function __construct(){
        $this->con = new Consultas();
    }
   
    public function opcionesMunicipioCP($cp) {
        $eid = $this->getMunicipiobyCP($cp); 
        $opciones = $this->getMunicipioClv();
        $op = "";
        foreach ($opciones as $actual) {
            $selected = "";
            if($eid == $actual['id_municipio']){
                $selected = "selected";
            }
            //$op .= "<option $selected id='municipio" . $actual['id_municipio'] . "' value='" . $actual['id_municipio'] . "'>" . $actual['municipio'] . ' - ' . $actual['municipio'] . "</option>";
            $op .= "<option $selected id='municipio" . $actual['id_municipio'] . "' value='" . $actual['id_municipio'] . "'>" . $actual['municipio'] . "</option>";

        }
        $json = array();
        $json['datosm']= $op;
        return $json;
     
    }
    
    private function getMunicipioByCP($cp) {
        $eid = "";
        $datos = $this->getmunicipiobyCPAUX($cp); //busca el municipio por codigo postal
        foreach ($datos as $actual) {
            $eid = $actual['id_municipio'];
            break;
        }
        return $eid;
    }
    private function getmunicipiobyCPAUX($cp) {
        $consultado = false;
        $consultas = new Consultas();
        $c_estado = $this->getCEstado($cp);
        $consulta = "SELECT * FROM catalogo_municipios WHERE c_estado=:cestado;";
        $val = array("cestado" => $c_estado);
        $consultado = $consultas->getResults($consulta, $val);
        return $consultado;
    }
    

    private function getEstadobyCPAUX($cp) {
        $consultado = false;
        $consultas = new Consultas();
        $c_estado = $this->getCEstado($cp);
        $consulta = "SELECT * FROM catalogo_estados WHERE c_estado=:cestado;";
        $val = array("cestado" => $c_estado);
        $consultado = $consultas->getResults($consulta, $val);
        return $consultado;
    }

    public function opcionesEstadoCP($cp) {
        $eid = $this->getEstadobyCP($cp); 
        $opciones = $this->getEstadoClv();
        $op = "";
        foreach ($opciones as $actual) {
            $selected = "";
            if($eid == $actual['idestado']){
                $selected = "selected";
            }
            $op .= "<option $selected id='nombre_estado" . $actual['idestado'] . "' value='" . $actual['idestado'] . "'>" . $actual['c_estado'] . ' - ' . $actual['nombre_estado'] . "</option>";
        }
        $json = array();
        $json['datos']= $op;
        return $json;
    }
//obtener el id del estado
    private function getEstadobyCP($cp) { 
        $eid = "";
        $datos = $this->getEstadobyCPAUX($cp); //busca el estado por codigo postal
        foreach ($datos as $actual) {
            $eid = $actual['idestado'];
        }
        return $eid;
    }
//ordena los datos

    private function getEstadoClv() {
        $consultado = false;
        $consulta = "SELECT * FROM catalogo_estados ORDER BY c_estado;";
        $consultas = new Consultas();
        $consultado = $consultas->getResults($consulta, null);
        return $consultado;
    }
    private function getMunicipioClv() {
        $consultado = false;
        $consulta = "SELECT * FROM catalogo_municipios ORDER BY c_estado;";
        $consultas = new Consultas();
        $consultado = $consultas->getResults($consulta, null);
        return $consultado;
    }
  
    public function opcionesEstadoClv($idestado = "") {
        $opciones = $this->getEstadoClv();
        $op = "";
        foreach ($opciones as $actual) {
            $selected = "";
            if($idestado == $actual['idestado']){
                $selected = "selected";
            }
            $op .= "<option $selected id='nombre_estado" . $actual['idestado'] . "' value='" . $actual['idestado'] . "'>" . $actual['c_estado'] . ' - ' . $actual['nombre_estado'] . "</option>";
        }
        $json = array();
        $json['datos'] = $op;
        return $json;
    }
//busca los municipios correspondientes por estado
    public function opcionesMunicipioByEstado($id, $idmunicipio = '') {
        $municipios = $this->getMunicipiosByEstado($id);//obtiene los munuicipios correspondientes
        $muni = ""; 
        foreach ($municipios as $municipio) {
            $selected = "";
            if ($idmunicipio == $municipio['id_municipio']) {
                $selected = "selected";
            }
            $muni .= "<option value='" . $municipio['id_municipio'] . "' $selected>" . $municipio['municipio'] . "</option>";
        }
        $json= array();
        $json['datos'] = $muni;
        return $json;
    }

    private function getMunicipiosByEstado($id) {
        $consultado = false;
        $consulta= "SELECT municipios.id_municipio, municipios.c_municipio, municipios.c_estado, municipios.municipio
        FROM catalogo_municipios AS municipios
        INNER JOIN catalogo_estados AS estados ON municipios.c_estado = estados.c_estado
        WHERE estados.idestado = :idestado
        ORDER BY municipios.municipio ASC";
        $valores = array("idestado" => $id);
        $consultas = new Consultas();
        $consultado = $consultas->getResults($consulta, $valores);
        return $consultado;
    }

    private function getCEstado($codpostal) {
        $c_estado = "0";
        $servidor = "localhost";
        $basedatos = "sineacceso";
        $puerto = "3306";
        $mysql_user = "root";
        $mysql_password = ""; //S1ne15QvikXJWc
        
        try {
            $db = new PDO("mysql:host=$servidor;port=$puerto;dbname=$basedatos", $mysql_user, $mysql_password);
            $stmttable = $db->prepare("SELECT * FROM catalogo_codpostal WHERE c_CodigoPostal='$codpostal'");

            if ($stmttable->execute()) {
                $resultado = $stmttable->fetchAll(PDO::FETCH_ASSOC);
                foreach ($resultado as $actual) {
                    $c_estado = $actual["c_Estado"];
                }
                return "$c_estado";
            } else {
                return "0";
            }
        } catch (PDOException $ex) {
            echo '<e>No se puedeeeee conectar a la bd ' . $ex->getMessage();
        }
    }

    public function opcionesBanco($idbanco = "") {
        $opciones = $this->getBancoAux();
        $opcionesbnc = "";
        foreach ($opciones as $actual) {
            $selected = "";
            if($idbanco == $actual['idcatalogo_banco']){
                $selected = "selected";
            }
            $opcionesbnc .= "<option $selected id='banco" . $actual['idcatalogo_banco'] . "' value='" . $actual['idcatalogo_banco'] . "'>" . $actual['c_banco'] . ' - ' . $actual['nombre_banco'] . "</option>";
        }
        $json= array();
        $json['datos'] = $opcionesbnc;
        return $json;
    }

    private function getBancoAux() {
        $consultado = false;
        $consulta = "select * from catalogo_banco order by c_banco;";
        $consultas = new Consultas();
        $consultado = $consultas->getResults($consulta, null);
        return $consultado;
    }

    public function addopcionesBanco($a, $idbanco = "") {
        $banco = $this->getBancoAux();
        $addbnco = "";
        foreach ($banco as $bancoactual) {
            $selected = "";
            if($idbanco == $bancoactual['idcatalogo_banco']){
                $selected = "selected";
            }
            $addbnco .= "<option $selected id='" . $a . "banco" . $bancoactual['idcatalogo_banco'] . "' value='" . $bancoactual['idcatalogo_banco'] . "'>" . $bancoactual['c_banco'] . ' - ' . $bancoactual['nombre_banco'] . "</option>";
        }
        $json = array();
        $json ['datos'] = $addbnco;
        return $json;
    }

}
?>