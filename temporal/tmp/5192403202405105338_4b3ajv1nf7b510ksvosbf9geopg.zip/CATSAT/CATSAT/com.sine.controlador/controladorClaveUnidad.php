<?php
require_once '../com.sine.dao/Consultas.php';

class controladorClaveUnidad{
    
    private $con;

    function __construct(){
        $this->con = new Consultas();
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_claveunidad $condicion";
        $consultado = $this->con->getResults($query, null);
        return $consultado;
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE (c_claveunidad LIKE '%$val%' OR nombre_unidad LIKE '%$val%') LIMIT 12;";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_claveunidad'].' - '.$rs['nombre_unidad'];
            $json['c_claveunidad'] = $rs['c_claveunidad'];
            $json['nombre_unidad'] = $rs['nombre_unidad'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option value='".$rs['idclaveunidad']."'>".$rs['c_claveunidad'].' - '.$rs['nombre_unidad']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

}
?>