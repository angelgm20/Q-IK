<?php
require_once '../com.sine.dao/Consultas.php';
class controladorProdServ{
    
    private $con;

    function __construct(){
        $this->con = new Consultas();
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_prodserv $condicion";
        $consultado = $this->con->getResults($query, null);
        return $consultado;
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE (c_prodserv LIKE '%$val%' OR descripcion LIKE '%$val%') LIMIT 12;";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_prodserv'].' - '.$rs['descripcion'];
            $json['c_prodserv'] = $rs['c_prodserv'];
            $json['descripcion'] = $rs['descripcion'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option value='".$rs['idprodserv']."'>".$rs['c_prodserv'].' - '.$rs['descripcion']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }


}
?>