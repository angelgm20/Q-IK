<?php
require_once '../com.sine.dao/Consultas.php';
require_once '../vendor/autoload.php'; 

class ControladorMonedas{
    
    private $consultas;
 
    function __construct(){     
        $this->consultas = new Consultas();  
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE c_moneda LIKE '%$val%' OR descripcion LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_moneda'].' - '.$rs['descripcion'];
            $json['c_moneda'] = $rs['c_moneda'];
            $json['descripcion'] = $rs['descripcion'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogos_sat.catalogo_monedas $condicion";
        $consultado = $this->consultas->getResults($query, null);
        return $consultado;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option id='moneda". $rs['idmoneda']."' class='ps-2 text-start' value='".$rs['idmoneda']."'>".$rs['c_moneda'].' - '.$rs['descripcion']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

    private function getTipoCambioAux($idmoneda) {
        $consultado = false;
        $consulta = "SELECT * FROM catalogos_sat.catalogo_monedas WHERE idmoneda=:id;";
        $val = array("id" => $idmoneda);
        $consultado = $this->consultas->getResults($consulta, $val);
        return $consultado;
    }

    public function getCMoneda($idmoneda) {
        $c_moneda = "";
        $moneda = $this->getTipoCambioAux($idmoneda);
        foreach ($moneda as $actual) {
            $c_moneda = $actual['c_moneda'];
        }
        return $c_moneda;
    }

    public function getTipoCambio($idmoneda, $idmonedaF = '0', $tcambioF = '0', $tcambioP = '0') {
        $moneda = $this->getTipoCambioAux($idmoneda);
        foreach ($moneda as $actual) {
            $tcambio = $actual['tipo_cambio'];
        }
        if ($idmoneda == '1') {
            if ($idmonedaF == '1') {
                if ($tcambioF != "0") {
                    $tcambio = $tcambioF;
                } else {
                    foreach ($moneda as $actual) {
                        $tcambio = $actual['tipo_cambio'];
                    }
                }
            } 
        } else if ($idmoneda == '2') {
            if ($idmonedaF == '1') {
                if ($tcambioP != '0') {
                    $tcambio = $tcambioP;
                } else {
                    foreach ($moneda as $actual) {
                        $tcambio = $actual['tipo_cambio'];
                    }
                }
            } 
        } else if ($idmoneda == '3') {
            if ($idmonedaF == '1') {
                foreach ($moneda as $actual) {
                    $tcambio = $actual['tipo_cambio'];
                }
            } 
        }
        return $tcambio;
    }


    public function opcionesMoneda($idmoneda = "") {
        $moneda = $this->getDatosAux(';');
        $r = "";
        foreach ($moneda as $monedaactual) {
            $selected = "";
            if($idmoneda == $monedaactual['idmoneda']){
                $selected = "selected";
            }
            $r .= "<option" . ($selected ? " selected" : "") . " class='ps-2 text-start'  id='moneda" . $monedaactual['idmoneda'] . "' value='" . $monedaactual['idmoneda'] . "'>" . $monedaactual['c_moneda'] . ' ' . $monedaactual['descripcion'] . "</option>";
        }
        return $r;
    }
}