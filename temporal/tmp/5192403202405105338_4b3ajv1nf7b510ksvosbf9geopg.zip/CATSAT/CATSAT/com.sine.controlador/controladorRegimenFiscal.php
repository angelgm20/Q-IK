<?php
require_once '../com.sine.dao/Consultas.php';
class controladorRegimenFiscal{
    
    private $con;

    function __construct(){
        $this->con = new Consultas();
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_regimen $condicion";
        $consultado = $this->con->getResults($query, null);
        return $consultado;
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE c_regimenfiscal LIKE '%$val%' OR descripcion_regimen LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_regimenfiscal'].' - '.$rs['descripcion_regimen'];
            $json['c_regimenfiscal'] = $rs['c_regimenfiscal'];
            $json['descripcion_regimen'] = $rs['descripcion_regimen'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option value='".$rs['c_regimenfiscal']."'>".$rs['c_regimenfiscal'].' - '.$rs['descripcion_regimen']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

}
?>