<?php
require_once '../com.sine.dao/Consultas.php';

class controladorMetodoPago{
    
    private $consultas;

    function __construct(){
        $this->consultas = new Consultas();
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_metodo_pago $condicion";
        $consultado = $this->consultas->getResults($query, null);
        return $consultado;
    }

    public function getAutocomplete($val){
        $condicion = "WHERE c_metodopago LIKE '%$val%' OR descripcion LIKE '%$val%'";
        
        $results = $this->getDatosAux($condicion);
    
        $jsonArray = array_map(function ($rs) {
            return [
                'value' => $rs['c_metodopago'] . ' - ' . $rs['descripcion'],
                'c_metodopago' => $rs['c_metodopago'],
                'descripcion' => $rs['descripcion']
            ];
        }, $results);
    
        return $jsonArray ?: [['value' => 'No se encontraron registros']];
    }
    
    public function getOptions() {
        $stmt = $this->getDatosAux();
        $datos = "";
        foreach ($stmt as $rs) {
            $datos .= "<option value='{$rs['c_metodopago']}'>{$rs['c_metodopago']} - {$rs['descripcion']}</option>";
        }
        
        return [
            'status' => count($stmt),
            'datos' => $datos
        ];
    }
}