<?php
require_once '../com.sine.dao/Consultas.php';
require_once '../vendor/autoload.php';

class ControladorMunicipio{ 
    
    private $consultas;

    function __construct(){  
        $this->consultas = new Consultas();  
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_municipios $condicion";
        $consultado = $this->consultas->getResults($query, null); 
        return $consultado;
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE municipio LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['municipio'];
            $json['municipio'] = $rs['municipio'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option value='".$rs['id_municipio']."'>".$rs['municipio']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }

    public function getMunicipioAux($idmun) {
        $municipio = "";
        $mun = $this->getMunicipioById($idmun);
        foreach ($mun as $actual) {
            $municipio = $actual['municipio'];
        }
        return $municipio;
    }

    private function getMunicipioById($idmun) {
        $consultado = false;
        $consulta = "SELECT * FROM catalogos_sat.catalogo_municipios WHERE id_municipio=:id;";
        $valores = array("id" => $idmun);
        $consultado = $this->consultas->getResults($consulta, $valores);
        return $consultado;
    }
}
?>