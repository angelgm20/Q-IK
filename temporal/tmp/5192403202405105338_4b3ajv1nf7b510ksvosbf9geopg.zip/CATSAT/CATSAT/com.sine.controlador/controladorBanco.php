<?php
require_once '../com.sine.dao/Consultas.php';
require_once '../vendor/autoload.php'; 

class ControladorBanco{
    
    private $consultas;
 
    function __construct(){     
        $this->consultas = new Consultas();  
    }

    public function getAutocomplete($val){
        $contador = 0;
        $condicion = "WHERE c_banco LIKE '%$val%' OR nombre_banco LIKE '%$val%'";
        $jsonArray = array();
        $stmt = $this->getDatosAux($condicion);
        foreach($stmt as $rs){
            $contador++;
            $json = array();
            $json['value'] = $rs['c_banco'].' - '.$rs['nombre_banco'];
            $json['c_banco'] = $rs['c_banco'];
            $json['nombre_banco'] = $rs['nombre_banco'];
            $jsonArray[] = $json;
        }

        if($contador == 0){
            $json = array();
            $json['value'] = "No se encontraron registros";
            $jsonArray[] = $json;
        }

        return $jsonArray;
    }

    private function getDatosAux($condicion = ""){
        $query = "SELECT * FROM catalogo_banco $condicion";
        $consultado = $this->consultas->getResults($query, null);
        return $consultado;
    }

    public function getOptions(){
        $contador = 0;
        $datos = "";
        $stmt = $this->getDatosAux();
        foreach($stmt as $rs){
            $contador ++;
            $datos .= "<option id='banco". $rs['idcatalogo_banco']."' class='ps-2 text-start' value='".$rs['idcatalogo_banco']."'>".$rs['c_banco'].' - '.$rs['nombre_banco']."</option>";
        }
        $json = array();
        $json['status'] = $contador;
        $json['datos']  = $datos;
        return $json;
    }
}